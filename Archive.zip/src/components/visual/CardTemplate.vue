<template>
  <div class="card">

  </div>
</template>

<script>
  export default{
    data(){
      return{
        msg:'hello vue'
      }
    },
  }
</script>

<style lang="stylus">
  .card
    background red
</style>