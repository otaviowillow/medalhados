<template>
  <div class="carta-view">
    <carta-do-presidente></carta-do-presidente>
  </div>
</template>

<script>
  import CartaDoPresidente from '../components/CartaDoPresidente.vue'
  export default{
    components:{
      CartaDoPresidente
    }
  }
</script>
